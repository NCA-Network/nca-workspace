# Tech Spec — BusinessAI Assistant Landing Page

## Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^18.3.0 | UI framework |
| react-dom | ^18.3.0 | DOM renderer |
| vite | ^6.0.0 | Build tool |
| @vitejs/plugin-react | ^4.3.0 | React Vite plugin |
| typescript | ^5.7.0 | Type system |
| @types/react | ^18.3.0 | React type definitions |
| @types/react-dom | ^18.3.0 | ReactDOM type definitions |
| three | ^0.170.0 | WebGPU fluid simulation (TSL, WebGPURenderer, wgslFn) |
| @types/three | ^0.170.0 | Three.js type definitions |
| gsap | ^3.12.7 | All animations — ScrollTrigger, timeline sequences |
| lenis | ^1.1.18 | Smooth scroll with scroll velocity for shader uniforms |

No Tailwind CSS. All styling is custom CSS.

## Component Inventory

### Layout

| Component | Source | Notes |
|-----------|--------|-------|
| Navigation | Custom | Fixed nav with scroll-aware shadow transition |
| Footer | Custom | Four-column link groups + bottom bar |
| SmoothScrollProvider | Custom | Lenis init + GSAP ScrollTrigger wiring, exposes instance via ref for shader uniform reads |

### Sections

| Component | Source | Notes |
|-----------|--------|-------|
| HeroSection | Custom | Contains FluidCanvas + text overlay + scroll indicator |
| TrustedByBar | Custom | Logo text badges row |
| FeaturesSection | Custom | 3-column grid of FeatureCard |
| HowItWorksSection | Custom | Dark section, 3-step layout with connector lines |
| IndustriesSection | Custom | 4-column grid of IndustryCard |
| ParallaxShowcase | Custom | Full-height parallax background image section |
| PricingSection | Custom | 3-column pricing card layout |
| FAQSection | Custom | Accordion list, single-open behavior |

### Reusable Components

| Component | Source | Used By |
|-----------|--------|---------|
| FluidCanvas | Custom | HeroSection — raw Three.js WebGPU renderer (not R3F) |
| FeatureCard | Custom | FeaturesSection — icon + title + description |
| IndustryCard | Custom | IndustriesSection — gradient bg + icon + label |
| PricingCard | Custom | PricingSection — 3 variants (Starter/Pro/Business) |
| FAQItem | Custom | FAQSection — accordion toggle |
| PillButton | Custom | Navigation, HeroSection, ParallaxShowcase, PricingSection |
| SectionHeader | Custom | Multiple sections — label + heading + subtext pattern |

## Animation Implementation

| Animation | Library | Approach | Complexity |
|-----------|---------|----------|------------|
| WebGPU fluid simulation | Three.js (TSL + WebGPURenderer) | Raw Three.js: OrthographicCamera + PlaneGeometry + ShaderMaterial with TSL node graph. 21 noise evaluations per pixel (fbm, snoise, vnoise). Mouse ripple + chromatic aberration. | 🔒 High |
| Scroll hue shift on fluid | Three.js + Lenis | Shader `scrollVelocity` uniform driven by `lenis.velocity * 0.001`, `scrollOffset` from `lenis.scroll`. Updated every frame. | Low |
| Hero text entrance | GSAP | Timeline: staggered line fade-in (y:30→0, opacity, 0.15s stagger) + subtitle delay + CTA row | Medium |
| Scroll indicator fade | GSAP ScrollTrigger | `scrub: true`, opacity 1→0 over first 500px of scroll | Low |
| TrustedBy entrance | GSAP ScrollTrigger | `toggleActions`, fade + y:20→0 | Low |
| Features header entrance | GSAP ScrollTrigger | Label slides from left, heading/subtext stagger up | Low |
| Features cards stagger | GSAP ScrollTrigger | 6 cards: opacity 0→1, y:50→0, scale:0.96→1, stagger 0.1s | Low |
| HowItWorks steps stagger | GSAP ScrollTrigger | 3 steps: x:-40→0, stagger 0.2s, dark bg section | Low |
| Industries cards scale-in | GSAP ScrollTrigger | 8 cards: scale 0.9→1, stagger 0.08s, `back.out(1.4)` | Low |
| Parallax background | GSAP ScrollTrigger | `scrub: true`, yPercent -20→20 on image layer with scale(1.4) | Medium |
| Parallax text entrance | GSAP ScrollTrigger | Content fade + y:40→0, trigger at top 60% | Low |
| Pricing cards entrance | GSAP ScrollTrigger | Side cards y:40→0, center card scale:0.95→1 with back.out(1.2) | Low |
| FAQ items stagger | GSAP ScrollTrigger | y:20→0, stagger 0.08s | Low |
| FAQ accordion open/close | GSAP | Height 0↔auto + opacity, icon rotation 0↔45deg, single-open state | Medium |
| Footer entrance | GSAP ScrollTrigger | Fade + y:30→0 | Low |
| Nav scroll shadow | GSAP ScrollTrigger | Toggle class when scroll past hero height | Low |

## State & Logic

### WebGPU ↔ Lenis Bridge

The FluidCanvas reads `lenis.scroll` and `lenis.velocity` every frame to drive shader uniforms. Plan: SmoothScrollProvider stores the Lenis instance in a ref (not state). FluidCanvas accesses this ref directly in its render loop via a shared callback or context. No React re-renders involved — pure imperative reads.

### WebGPU Fallback

FluidCanvas must detect `navigator.gpu` support. If unavailable, unmount the canvas and apply a CSS animated gradient fallback to the hero container. This check is synchronous at mount time — no async initialization path.

### Hero Renderer Lifecycle

Raw Three.js WebGPURenderer requires manual lifecycle:
1. Mount: create renderer → compile TSL material → start render loop
2. Resize: ResizeObserver on hero container → `renderer.setSize()` + `camera.updateProjectionMatrix()` + update `resolution` uniform
3. Visibility: IntersectionObserver (threshold 0.1) → `renderer.pause()` / `renderer.resume()`
4. Unmount: dispose renderer, geometry, material, stop render loop

All managed imperatively in a `useEffect` — no React Three Fiber abstraction.

## Other Key Decisions

### Raw Three.js over React Three Fiber

The shader requires `WebGPURenderer` and TSL (`three/webgpu` entry point). R3F's declarative model adds complexity for a single full-screen quad with imperative uniform updates. Raw Three.js in a `useEffect` is simpler and avoids R3F's reconciler overhead for this use case.

### No shadcn/ui Components

The design specifies fully custom components with unique styling (pill buttons, custom cards, specific border radii, hover effects). None of the standard shadcn patterns apply. All components are hand-built.

### Custom CSS Architecture

All styles in `.css` files (no CSS-in-JS). Global styles for design tokens in `index.css` (CSS custom properties for colors, spacing). Component-level styles in co-located `.css` files or scoped via class naming convention. Font imports for PP Editorial New (CDN or `@font-face`) and DM Sans (Google Fonts).
